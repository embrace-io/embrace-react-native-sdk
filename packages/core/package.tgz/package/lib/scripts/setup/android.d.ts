import Wizard from "../util/wizard";
export declare const androidEmbraceSwazzler: RegExp;
export declare const androidGenericVersion = "classpath \"io.embrace:embrace-swazzler:${findProject(':embrace-io_react-native').properties['emb_android_sdk']}\"";
export declare const patchBuildGradle: {
    name: string;
    run: (wizard: Wizard) => Promise<any>;
    docURL: string;
};
export declare const androidEmbraceSwazzlerPluginRE: RegExp;
export declare const androidEmbraceSwazzlerPlugin = "apply plugin: 'embrace-swazzler'";
export declare const patchAppBuildGradle: {
    name: string;
    run: (wizard: Wizard) => Promise<any>;
    docURL: string;
};
export declare const createEmbraceJSON: {
    name: string;
    run: (wizard: Wizard) => Promise<any>;
    docURL: string;
};
export declare const patchMainApplication: {
    name: string;
    run: (wizard: Wizard) => Promise<any>;
    docURL: string;
};
