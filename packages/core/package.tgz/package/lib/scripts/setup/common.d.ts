export interface IPackageJson {
    name: string;
    dependencies: Record<string, string>;
}
export declare const iosAppID: {
    name: string;
    fetch: () => Promise<string>;
};
export declare const androidAppID: {
    name: string;
    fetch: () => Promise<string>;
};
export declare const apiToken: {
    name: string;
    fetch: () => Promise<string>;
};
export declare const packageJSON: {
    name: string;
    fetch: () => Promise<any>;
};
