import Wizard from "../util/wizard";
import { IPackageJson } from "./common";
export declare const tryToPatchAppDelegate: ({ name, }: {
    name: string;
}) => Promise<boolean>;
export declare const iosInitializeEmbrace: {
    name: string;
    run: (wizard: Wizard) => Promise<boolean>;
    docURL: string;
};
export declare const patchPodfile: (json: IPackageJson) => Promise<void> | undefined;
export declare const iosPodfile: {
    name: string;
    run: (wizard: Wizard) => Promise<any>;
    docURL: string;
};
export declare const patchXcodeBundlePhase: {
    name: string;
    run: (wizard: Wizard) => Promise<any>;
    docURL: string;
};
export declare const addUploadBuildPhase: {
    name: string;
    run: (wizard: Wizard) => Promise<any>;
    docURL: string;
};
export declare const addEmbraceInitializerSwift: {
    name: string;
    run: (wizard: Wizard) => Promise<any>;
    docURL: string;
};
