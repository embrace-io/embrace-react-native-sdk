import { FileUpdatable } from "../../util/file";
export declare const JAVA_MAIN_ACTIVITY = "MainApplication.java";
export declare const KOTLIN_MAIN_ACTIVITY = "MainApplication.kt";
export declare const SWIFT_APP_DELEGATE = "AppDelegate.swift";
export declare const OBJECTIVEC_APP_DELEGATE = "AppDelegate.*(m|mm)";
/**
 * Adds a line to the specified file after the specified search text.
 *
 * This function will return true if the line was successfully added to the file.
 *
 * @param file The file where the new line will be added.
 * @param lineToAdd The line that will be added to the file.
 * @param searchText The text used to determine the location where the new line will be added.
 *                   The new line will be added after the first occurrence of this text.
 * @param fileName The name of the file, used only for logging purposes.
 * @return Returns true if the line was successfully added to the file, false if the line already exists.
 */
declare const addLineAfterToTextInFile: (file: FileUpdatable, lineToAdd: string, searchText: string | RegExp, fileName?: string) => boolean;
/**
 * Adds a line to the specified file after the specified search text.
 *
 * This function will return true if the line was successfully added to the file.
 *
 * @param file The file where the new line will be added.
 * @param lineToAdd The line that will be added to the file.
 * @param searchText The text used to determine the location where the new line will be added.
 *                   The new line will be added after the first occurrence of this text.
 * @param fileName The name of the file, used only for logging purposes.
 * @return Returns true if the line was successfully added to the file, false if the line already exists.
 */
declare const addLineBeforeToTextInFile: (file: FileUpdatable, lineToAdd: string, searchText: string | RegExp, fileName?: string) => boolean;
declare type ANDROID_LANGUAGE = "kotlin" | "java";
declare type IOS_LANGUAGE = "swift" | "objectivec" | "swift5x" | "objectivec5x";
declare type SUPPORTED_LANGUAGES = IOS_LANGUAGE | ANDROID_LANGUAGE;
declare const MAIN_CLASS_BY_LANGUAGE: Record<SUPPORTED_LANGUAGES, string>;
declare type ORDER = "after" | "before";
declare type BREAKINGLINE_ORDER = ORDER | "none" | "both";
declare type DynamicTextParameters = {
    bridgingHeader?: string;
};
declare type DynamicText = (params: DynamicTextParameters) => string[];
interface TextToAdd {
    searchText: string | RegExp;
    textToAdd: string | string[] | DynamicText;
    order: ORDER;
    breakingLine: BREAKINGLINE_ORDER;
}
declare type FindFileFunction = (language: SUPPORTED_LANGUAGES, projectName?: string) => FileUpdatable | undefined;
interface IPatchDefinition {
    fileName: string;
    textsToAdd: TextToAdd[];
    findFileFunction: FindFileFunction;
}
export { addLineAfterToTextInFile, addLineBeforeToTextInFile, MAIN_CLASS_BY_LANGUAGE, SUPPORTED_LANGUAGES, ANDROID_LANGUAGE, IOS_LANGUAGE, TextToAdd, IPatchDefinition, BREAKINGLINE_ORDER, };
export type { DynamicTextParameters };
