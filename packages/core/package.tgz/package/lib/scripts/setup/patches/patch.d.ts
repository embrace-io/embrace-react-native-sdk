import { BREAKINGLINE_ORDER, DynamicTextParameters, IPatchDefinition, SUPPORTED_LANGUAGES, TextToAdd } from "./common";
export declare const EMBRACE_INIT_SWIFT = "EmbraceInitializer.start()";
export declare const EMBRACE_IMPORT_JAVA = "import io.embrace.android.embracesdk.Embrace;";
export declare const EMBRACE_INIT_JAVA = "Embrace.getInstance().start(this, false, Embrace.AppFramework.REACT_NATIVE);";
export declare const EMBRACE_IMPORT_KOTLIN = "import io.embrace.android.embracesdk.Embrace";
export declare const EMBRACE_INIT_KOTLIN = "Embrace.getInstance().start(this, false, Embrace.AppFramework.REACT_NATIVE)";
declare type SupportedPatches = {
    [key in SUPPORTED_LANGUAGES]: IPatchDefinition | undefined;
};
export declare const SUPPORTED_PATCHES: SupportedPatches;
export declare const SUPPORTED_REMOVALS: {
    swift5x: IPatchDefinition;
    objectivec5x: IPatchDefinition;
    kotlin: IPatchDefinition | undefined;
    java: IPatchDefinition | undefined;
    swift: IPatchDefinition | undefined;
    objectivec: IPatchDefinition | undefined;
};
export declare const getText: (item: TextToAdd, dynamicTextParams?: DynamicTextParameters) => string | string[];
export declare const getTextToAddWithBreakingLine: (textToAdd: string | string[], breakingLine: BREAKINGLINE_ORDER, padding?: string) => string;
declare const patch: (language: SUPPORTED_LANGUAGES, projectName?: string, dynamicTextParams?: DynamicTextParameters) => boolean | void;
export default patch;
