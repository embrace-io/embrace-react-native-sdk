import { IPatchDefinition } from "./common";
export declare const EMBRACE_IMPORT_OBJECTIVEC_5X = "#import <Embrace/Embrace.h>";
export declare const EMBRACE_INIT_OBJECTIVEC_5X = "[[Embrace sharedInstance] startWithLaunchOptions:launchOptions framework:EMBAppFrameworkReactNative];";
export declare const EMBRACE_IMPORT_SWIFT_5X = "import Embrace";
export declare const EMBRACE_INIT_SWIFT_5X = "Embrace.sharedInstance().start(launchOptions: launchOptions, framework:.reactNative)";
export declare const PATCH_IOS_SWIFT_APPDELEGATE_5X: IPatchDefinition;
export declare const PATCH_IOS_OBJECTIVEC_APPDELEGATE_5X: IPatchDefinition;
