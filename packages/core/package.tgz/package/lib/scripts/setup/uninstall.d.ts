import { FileUpdatable } from "../util/file";
import { SUPPORTED_LANGUAGES } from "./patches/common";
interface ITextToDelete {
    ITextToDelete: string | RegExp;
}
declare type FindFileFunction = () => FileUpdatable | undefined;
interface IUnlinkEmbraceCode {
    stepName: string;
    fileName: string;
    textsToDelete: ITextToDelete[];
    findFileFunction: FindFileFunction;
    docUrl: string;
}
declare type UNLINK_EMBRACE_CODE = "swazzlerImport" | "swazzlerApply" | "podFileImport";
declare type SupportedPatches = {
    [key in UNLINK_EMBRACE_CODE]: IUnlinkEmbraceCode;
};
declare const UNLINK_EMBRACE_CODE: SupportedPatches;
export declare const removeEmbraceLinkFromFile: (patch: UNLINK_EMBRACE_CODE) => boolean;
export declare const removeEmbraceImportAndStartFromFile: (patch: SUPPORTED_LANGUAGES) => boolean;
export declare const removeEmbraceConfigFileAndroid: () => Promise<void>;
export declare const removeEmbraceConfigFileIos: () => Promise<void>;
export declare const removeEmbraceInitializerFileIos: () => Promise<boolean>;
export declare const removeEmbraceFromXcode: () => Promise<unknown>;
export {};
