import { ANDROID_LANGUAGE } from "../setup/patches/common";
import { FileUpdatable } from "./file";
export declare const getBuildGradlePatchable: (paths?: string[]) => FileUpdatable;
export declare const buildGradlePatchable: () => Promise<FileUpdatable>;
export declare const buildAppGradlePatchable: () => Promise<FileUpdatable>;
export declare const embraceJSON: () => Promise<FileUpdatable>;
export declare const getMainApplicationPatchable: (platform: ANDROID_LANGUAGE) => FileUpdatable | undefined;
export declare const mainApplicationPatchable: (platform: ANDROID_LANGUAGE) => Promise<FileUpdatable>;
export declare const embraceJSONContents: (params: {
    appID: string;
    apiToken: string;
}) => string;
