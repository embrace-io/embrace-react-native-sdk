export interface Askable {
    ask: (question: Question) => Promise<Answer>;
}
export interface Question {
    name: string;
    message: string;
}
export interface Answer {
    [key: string]: string;
}
declare class Asker implements Askable {
    answers: Answer;
    constructor();
    ask(...question: Question[]): Promise<Answer>;
}
export default Asker;
