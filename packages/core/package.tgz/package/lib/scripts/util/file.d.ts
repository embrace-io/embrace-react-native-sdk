export interface Patchable {
    patch: () => void;
    path: string;
}
export interface FileUpdatable extends Patchable {
    contents: string;
    addBefore: (line: string | RegExp, add: string) => void;
    addAfter: (line: string | RegExp, add: string) => void;
    hasLine: (line: string | RegExp) => boolean;
    getPaddingFromString: (searchString: string) => string;
    getPaddingAfterStringToTheNextString: (searchString: RegExp) => string;
    deleteLine: (line: string | RegExp) => void;
}
export declare const patchFiles: (...files: Array<() => Promise<Patchable>>) => Promise<void>;
export declare const NoopFile: {
    path: string;
    contents: string;
    patch: () => void;
    hasLine: (_: string) => boolean;
    getPaddingFromString: (searchString: string) => string;
    getPaddingAfterStringToTheNextString: (searchString: RegExp) => string;
    addBefore: (line: string, add: string) => void;
    addAfter: (line: string, add: string) => void;
    deleteLine: (line: string) => void;
};
export declare const getFileContents: (path: string) => FileUpdatable;
