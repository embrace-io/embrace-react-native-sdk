import { IOS_LANGUAGE } from "../setup/patches/common";
import { FileUpdatable, Patchable } from "./file";
export declare const embraceNativePod = "pod 'EmbraceIO'";
export declare const bundlePhaseRE: RegExp;
export declare const exportSourcemapRNVariable = "export SOURCEMAP_FILE=\"$CONFIGURATION_BUILD_DIR/main.jsbundle.map\";";
export declare const EMBRACE_IMPORT_OBJECTIVEC: ({ bridgingHeader, }: {
    bridgingHeader?: string | undefined;
}) => string[];
export declare const EMBRACE_INIT_OBJECTIVEC = "[EmbraceInitializer start];";
export declare const embRunScript = "\"${PODS_ROOT}/EmbraceIO/run.sh\"";
export declare type ProjectFileType = "resource" | "source";
export declare const getAppDelegateByIOSLanguage: (projectName: string, language: IOS_LANGUAGE) => FileUpdatable | undefined;
export declare const getPodFile: () => FileUpdatable;
export declare const podfilePatchable: () => Promise<FileUpdatable>;
export declare const embracePlistPatchable: () => Promise<FileUpdatable>;
export declare const xcodePatchable: ({ name, }: {
    name: string;
}) => Promise<XcodeProject>;
export declare const getXcodeProject: (path: string) => Promise<XcodeProject>;
export declare class XcodeProject implements Patchable {
    project: any;
    path: string;
    constructor(path: string | undefined, project: any);
    buildPhaseObj(): {
        [key: string]: any;
    };
    hasLine(key: string, line: string | RegExp): boolean;
    modifyPhase(key: string, line: string | RegExp, add: string): void;
    findPhase(line: string | RegExp): string;
    findAndRemovePhase(line: string | RegExp): void;
    patch(): void;
    writeSync(): any;
    addFile(groupName: string, path: string, fileType?: ProjectFileType): void;
    getBridgingHeaderName(groupName: string): string;
    private getTargetHash;
    private getBuildProperty;
    private updateBuildProperty;
    removeResourceFile(groupName: string, path: string): void;
    private findHash;
    addBridgingHeader(projectName: string): Promise<boolean>;
}
export declare const projectNameToBridgingHeader: (projectName: string) => string;
export declare const findNameWithCaseSensitiveFromPath: (path: string, name: string) => string;
