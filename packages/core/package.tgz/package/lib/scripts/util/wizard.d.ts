export interface Field {
    name: string;
    fetch: () => Promise<any>;
}
export interface Step {
    name: string;
    run: (wizard: Wizard) => Promise<any>;
    isCompleted?: boolean;
    docURL: string;
}
declare class Wizard {
    private fields;
    private steps;
    private fieldValues;
    constructor();
    registerField(field: Field): void;
    registerStep(step: Step): void;
    fieldValue(field: Field): Promise<any>;
    fieldValueList(list: Field[]): Promise<any[]>;
    getUncompletedSteps(): Step[];
    processSteps(): Promise<any[]>;
    runSteps(): Promise<void>;
}
export default Wizard;
