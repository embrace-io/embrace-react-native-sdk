import { IAxios } from "./IAxios";
export declare type NETWORK_SDK_INTERCEPTORS = "axios";
export declare type NETWORK_INTERCEPTOR_TYPES = IAxios;
/**
 * This methods validates if the instance is supported by Embrace
 * and returns its type
 * @param providerInstance
 * @returns Provider interceptor type
 */
export declare const getNetworkSDKInterceptorProvider: (providerInstance: NETWORK_INTERCEPTOR_TYPES) => "axios" | undefined;
