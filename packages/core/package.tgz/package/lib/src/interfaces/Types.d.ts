export declare type SessionStatus = "INVALID" | "CRASH" | "CLEAN_EXIT";
