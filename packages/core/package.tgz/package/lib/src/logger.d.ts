interface Logger {
    log: (message: string) => void;
    warn: (message: string) => void;
    error: (message: string) => void;
}
interface MessageFormatter {
    format: (message: string) => string;
}
declare class EmbraceLogger implements Logger, MessageFormatter {
    out: Logger;
    constructor(out: Logger);
    format(message: string): string;
    log(message: string): void;
    warn(message: string): void;
    error(message: string): void;
}
export default EmbraceLogger;
