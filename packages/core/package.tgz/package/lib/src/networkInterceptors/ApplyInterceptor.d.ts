import { NETWORK_INTERCEPTOR_TYPES, NETWORK_SDK_INTERCEPTORS } from "../interfaces/NetworkMonitoring";
interface IIntercerptorStrategy {
    applyInterceptor: (interceptor: NETWORK_INTERCEPTOR_TYPES) => void;
}
declare type APPLY_INTERCEPTOR_STRATEGY = Record<NETWORK_SDK_INTERCEPTORS, IIntercerptorStrategy>;
export declare const ApplyInterceptorStrategy: APPLY_INTERCEPTOR_STRATEGY;
export {};
