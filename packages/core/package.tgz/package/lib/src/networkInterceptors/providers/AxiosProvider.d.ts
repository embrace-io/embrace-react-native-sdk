import { IAxios } from "../../interfaces/IAxios";
/**
 * This method injects the Axios interceptors to the instance passed through params
 * We use those interceptors to track the request and response of your API calls.
 * The tracked data will be displayed on the dashboard
 * @param networkSDKInstance
 */
export declare const applyAxiosNetworkInterceptor: (networkSDKInstance: IAxios) => void;
