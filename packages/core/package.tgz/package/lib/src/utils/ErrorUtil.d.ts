declare type ErrorHandler = (error: Error, callback: () => void) => void;
declare type GlobalErrorHandler = (previousHandler: (error: Error, isFatal?: boolean) => void, handleError: ErrorHandler) => (error: Error, isFatal?: boolean) => void;
declare const handleGlobalError: GlobalErrorHandler;
export { handleGlobalError };
